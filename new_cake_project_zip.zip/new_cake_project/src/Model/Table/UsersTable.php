<?php
namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class UsersTable extends Table
{
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('users'); // Set the table name

        // Define associations, validation rules, behaviors, etc.
    }

    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->notEmptyString('email', 'An email is required')

            ->notEmptyString('password', 'A password is required');


        return $validator;
    }
}
