<?php
    namespace App\Controller;

    use App\Controller\AppController;
    use Cake\Event\EventInterface;
    class UsersController extends AppController
    {
      public function beforeFilter(EventInterface $event) {
    $this->Auth->allow(['registration','dashboard','logout']);
}

public function dashboard(){

}

      public function registration() {
          $user = $this->Users->newEmptyEntity();

          if ($this->request->is('post')) {
              $users=$this->Users->patchEntity($user, $this->request->getdata());

              if ($this->Users->save($user)) {
                  $this->Flash->success(__('Registration successful.'));
                  return $this->redirect(['action' => 'registration']);
              } else {
                  $this->Flash->error('Registration failed. Please, try again.');
              }
          }
         $this->set('user',$user);

      }

      public function login()
{
    if ($this->request->is(['post'])) {
        $user = $this->Auth->identify();
        if ($user) {
            $this->Auth->setUser($user);
            return $this->redirect(['action' => 'dashboard']);
        } else {
            $this->Flash->error(__('Invalid username or password, please try again.'));
        }
    }
}


     public function logout(){
       $this->Auth->logout();
       return $this->redirect(['action'=>'login']);
     }


    }
