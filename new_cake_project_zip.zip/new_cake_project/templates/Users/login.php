
<h1>LOGIN FORM</h1>

<?php

echo $this->Form->create();

echo $this->Form->input('email',['label' => false, 'placeholder' => 'Enter your email']).'<br>';
echo $this->Form->input('password',['label' => false, 'placeholder' => 'Enter your password','type'=>'password']).'<br>';
echo $this->Form->button('login');
echo $this->Form->end();
?>
