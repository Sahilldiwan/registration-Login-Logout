<h1>welcome user </h1>
<a href="logout"> Logout </a>
